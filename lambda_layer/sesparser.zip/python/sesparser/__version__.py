# .::.  ::  :: ..::.. \  / ..::..
# :...  ::  :: ::__::  ::  ::__::
# :..:  :...:: ::  \\  ::  ::  ::

__title__ = "sesparser_suryavaddiraju"
__description__ = "SES Incoming email Parser"
__url__ = "https://requests.readthedocs.io"
__version__ = "0.0.1"
__build__ = 0x0231107
__author__ = "Vaddiraju Surya Teja"
__author_email__ = "suryavaddiraju@proton.me"
__license__ = "Apache-2.0"
__copyright__ = "Copyright Vaddiraju Surya Teja"